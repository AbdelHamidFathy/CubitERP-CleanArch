package com.example.dexef_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
