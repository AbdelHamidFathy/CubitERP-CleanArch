class EndPoints {
  static const String baseUrl = 'http://quotes.stormconsultancy.co.uk/';
  static const String randomQuote = '${baseUrl}random.json';
}
