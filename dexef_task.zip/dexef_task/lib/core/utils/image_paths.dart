class ImagePaths{
  static const String splashScreen = "assets/images/Splash Screen.png";
}