import 'package:dexef_task/features/home/persentation/widgets/chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 5.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MyBarChart(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,),label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,),label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,),label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,),label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,),label: "Home"),
      ]),
    );
  }
}
