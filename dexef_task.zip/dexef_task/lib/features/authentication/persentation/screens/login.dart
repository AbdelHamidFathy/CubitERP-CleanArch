import 'package:dexef_task/core/utils/app_colors.dart';
import 'package:dexef_task/core/utils/app_strings.dart';
import 'package:dexef_task/core/widgets/custom_button.dart';
import 'package:dexef_task/core/widgets/custom_text.dart';
import 'package:dexef_task/core/widgets/vertical_space.dart';
import 'package:dexef_task/features/authentication/persentation/widgets/custom_form_field.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 5.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CustomText(
                    text: AppStrings.elhamadCompany,
                    fontSize: 12.sp,
                    fontColor: AppColors.primaryColor,
                  ),
                ],
              ),
              CustomText(
                text: AppStrings.userLogin.toUpperCase(),
                fontSize: 15.sp,
              ),
              const VerticalSpace(),
              CustomTextForm(
                isPassword: false,
                label: AppStrings.ip,
                controller: TextEditingController(),
                context: context,
                keyboardType: TextInputType.text,
              ),
              const VerticalSpace(),
              CustomTextForm(
                isPassword: false,
                label: AppStrings.dataBase,
                controller: TextEditingController(),
                context: context,
                keyboardType: TextInputType.text,
              ),
              const VerticalSpace(),
              CustomTextForm(
                isPassword: false,
                label: AppStrings.userName,
                controller: TextEditingController(),
                context: context,
                keyboardType: TextInputType.text,
              ),
              const VerticalSpace(),
              CustomTextForm(
                isPassword: false,
                label: AppStrings.password,
                controller: TextEditingController(),
                context: context,
                keyboardType: TextInputType.text,
              ),
              const VerticalSpace(),
              CustomButton(
                buttonText: AppStrings.logIn.toUpperCase(),
              ),
              const VerticalSpace(),
              CustomButton(
                buttonText: AppStrings.demoVersion.toUpperCase(),
                buttonColor: AppColors.green,
              ),
              const VerticalSpace(),
              CustomText(
                text: AppStrings.demoVersionYouCanBrowseOurDummyData,
                fontSize: 9.sp,
                fontColor: AppColors.grey,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
